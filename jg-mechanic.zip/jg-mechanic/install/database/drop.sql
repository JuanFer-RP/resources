DROP TABLE IF EXISTS `mechanic_vehicledata`;
DROP TABLE IF EXISTS `mechanic_settings`;
DROP TABLE IF EXISTS `mechanic_invoices`;
DROP TABLE IF EXISTS `mechanic_orders`;
DROP TABLE IF EXISTS `mechanic_servicing_history`;
DROP TABLE IF EXISTS `mechanic_employees`;
DROP TABLE IF EXISTS `mechanic_data`;
